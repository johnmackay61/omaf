# CONTRIBUTING.md
See prepared content in conversation.