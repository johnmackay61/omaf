# CASE-STUDY-TEMPLATE.md
See prepared content in conversation.