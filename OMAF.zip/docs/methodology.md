# methodology.md
See prepared content in conversation.